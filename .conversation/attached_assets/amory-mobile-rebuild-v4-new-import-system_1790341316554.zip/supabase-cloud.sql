-- AMORY cloud accounts + multi-device snapshot sync
-- Run once in Supabase SQL Editor.
create table if not exists public.cloud_workspaces (
  account_id uuid primary key references auth.users(id) on delete cascade,
  snapshot jsonb not null default '{}'::jsonb,
  version bigint not null default 1,
  updated_at timestamptz not null default now()
);

alter table public.cloud_workspaces enable row level security;

drop policy if exists "workspace_select_own" on public.cloud_workspaces;
drop policy if exists "workspace_insert_own" on public.cloud_workspaces;
drop policy if exists "workspace_update_own" on public.cloud_workspaces;
drop policy if exists "workspace_delete_own" on public.cloud_workspaces;

create policy "workspace_select_own" on public.cloud_workspaces for select using (auth.uid() = account_id);
create policy "workspace_insert_own" on public.cloud_workspaces for insert with check (auth.uid() = account_id);
create policy "workspace_update_own" on public.cloud_workspaces for update using (auth.uid() = account_id) with check (auth.uid() = account_id);
create policy "workspace_delete_own" on public.cloud_workspaces for delete using (auth.uid() = account_id);

-- Enable Realtime for the workspace row. If this reports that the table is already
-- in the publication, that is harmless.
alter publication supabase_realtime add table public.cloud_workspaces;
